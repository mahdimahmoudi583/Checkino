
package ir.checkino.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {

    private val gold = Color.rgb(217,164,65)
    private val bg = Color.rgb(11,13,16)
    private val surface = Color.rgb(21,25,31)
    private val white = Color.WHITE
    private val muted = Color.rgb(167,175,185)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(22, 18, 22, 18)
        return root
    }

    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.gravity = Gravity.RIGHT
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.setPadding(4, 5, 4, 5)
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 15f
        b.setTextColor(Color.BLACK)
        b.setOnClickListener { onClick() }
        val gd = GradientDrawable()
        gd.setColor(gold)
        gd.cornerRadius = 18f
        b.background = gd
        b.setPadding(12, 8, 12, 8)
        return b
    }

    private fun card(title: String, body: String, onClick: (() -> Unit)? = null): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(18, 14, 18, 14)
        val gd = GradientDrawable()
        gd.setColor(surface)
        gd.cornerRadius = 24f
        box.background = gd
        box.addView(text(title, 18f, white, true))
        box.addView(text(body, 13f, muted))
        if (onClick != null) {
            box.isClickable = true
            box.setOnClickListener { onClick() }
        }
        return box
    }

    private fun showHome() {
        val root = base()
        root.addView(text("چکینو", 30f, gold, true))
        root.addView(text("قبل از خرید، مطمئن شو.", 15f, muted))
        root.addView(space(16))

        root.addView(card("🔧 درخواست کارشناسی",
            "کارشناس حضوری برای لپ‌تاپ یا موبایل شما پیدا می‌کنیم.") {
            showRequest()
        }, LinearLayout.LayoutParams(-1, -2))

        root.addView(space(12))
        root.addView(card("📋 کارشناسی‌های من",
            "مشاهده وضعیت درخواست‌ها و گزارش‌های کارشناسی.") {
            showRequests()
        }, LinearLayout.LayoutParams(-1, -2))

        root.addView(space(12))
        root.addView(card("🛡️ خرید مطمئن",
            "نسخه اولیه آماده توسعه برای مهلت تست و تضمین کارشناسی.") {
            showGuarantee()
        }, LinearLayout.LayoutParams(-1, -2))

        root.addView(space(12))
        root.addView(text("همکاری با چکینو", 19f, white, true))
        root.addView(text("اگر فروشگاه‌دار، دارای پروانه کسب یا دانشجوی متخصص هستید، می‌توانید به شبکه کارشناسان بپیوندید.", 13f, muted))
        root.addView(space(8))
        root.addView(button("درخواست همکاری به عنوان کارشناس") { showExpertJoin() })

        root.addView(space(18))
        root.addView(text("نسخه آزمایشی 0.1 • MVP", 12f, muted))

        setContentView(root)
    }

    private fun showRequest() {
        val root = base()
        root.addView(text("درخواست کارشناسی", 25f, gold, true))
        root.addView(text("نوع دستگاه را انتخاب کنید", 15f, muted))
        root.addView(space(10))
        root.addView(button("💻 لپ‌تاپ") { showForm("لپ‌تاپ") })
        root.addView(space(10))
        root.addView(button("📱 موبایل") { showForm("موبایل") })
        root.addView(space(10))
        root.addView(button("← بازگشت") { showHome() })
        setContentView(root)
    }

    private fun showForm(device: String) {
        val root = base()
        root.addView(text("ثبت درخواست • $device", 23f, gold, true))
        val brand = EditText(this); brand.hint = "برند و مدل دستگاه"; styleEdit(brand)
        val city = EditText(this); city.hint = "شهر محل دستگاه"; styleEdit(city)
        val address = EditText(this); address.hint = "آدرس یا محدوده"; styleEdit(address)
        val link = EditText(this); link.hint = "لینک آگهی (اختیاری)"; styleEdit(link)
        root.addView(brand); root.addView(city); root.addView(address); root.addView(link)
        root.addView(space(10))
        root.addView(text("نوع خدمت", 15f, white, true))
        val types = arrayOf("کارشناسی استاندارد", "کارشناسی تخصصی", "کارشناسی فوری ⚡")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        root.addView(spinner)
        root.addView(space(14))
        root.addView(button("ثبت درخواست") {
            Toast.makeText(this, "درخواست آزمایشی ثبت شد؛ در نسخه بعد پرداخت و تخصیص کارشناس متصل می‌شود.", Toast.LENGTH_LONG).show()
            showRequests()
        })
        root.addView(space(8))
        root.addView(button("← بازگشت") { showRequest() })
        setContentView(root)
    }

    private fun styleEdit(e: EditText) {
        e.setTextColor(white); e.setHintTextColor(muted)
        e.textSize = 14f
        e.gravity = Gravity.RIGHT
        e.setPadding(14, 10, 14, 10)
    }

    private fun showRequests() {
        val root = base()
        root.addView(text("کارشناسی‌های من", 25f, gold, true))
        root.addView(space(12))
        root.addView(card("CHK-1001 • Dell Latitude 5420",
            "وضعیت: در انتظار تخصیص کارشناس\nشهر: مشهد\nنوع: کارشناسی استاندارد"))
        root.addView(space(10))
        root.addView(card("گزارش آماده",
            "برای مشاهده گزارش کارشناسی نمونه، این کارت را لمس کنید.") {
            showReport()
        })
        root.addView(space(14))
        root.addView(button("← بازگشت") { showHome() })
        setContentView(root)
    }

    private fun showReport() {
        val root = base()
        root.addView(text("گزارش کارشناسی", 25f, gold, true))
        root.addView(text("Dell Latitude 5420 • CHK-1001", 16f, white, true))
        root.addView(space(10))
        root.addView(card("امتیاز نهایی: 91 / 100", "وضعیت کلی: سالم"))
        root.addView(space(8))
        val rows = listOf(
            "بدنه" to "🟢 خوب",
            "نمایشگر" to "🟢 سالم",
            "باتری" to "🟡 82٪",
            "SSD" to "🟢 سالم",
            "RAM" to "🟢 سالم",
            "CPU" to "🟢 سالم",
            "پورت‌ها" to "🟢 سالم"
        )
        rows.forEach { (a,b) ->
            val row = LinearLayout(this)
            row.setPadding(10,6,10,6)
            row.addView(text(a, 14f, white, true), LinearLayout.LayoutParams(0,-2,1f))
            row.addView(text(b, 14f, white))
            root.addView(row)
        }
        root.addView(space(12))
        root.addView(card("کارشناس: علی احمدی", "امتیاز 4.9 از 5 • 428 کارشناسی"))
        root.addView(space(12))
        root.addView(button("⭐ امتیازدهی به کارشناس") {
            Toast.makeText(this, "بخش امتیازدهی در نسخه بعد تکمیل می‌شود.", Toast.LENGTH_SHORT).show()
        })
        root.addView(space(8))
        root.addView(button("← بازگشت") { showRequests() })
        setContentView(root)
    }

    private fun showGuarantee() {
        val root = base()
        root.addView(text("خرید مطمئن", 25f, gold, true))
        root.addView(space(8))
        root.addView(card("🛡️ مهلت تست و تضمین کارشناسی",
            "این بخش در معماری نسخه اول پیش‌بینی شده است. در نسخه‌های بعدی می‌توانیم مهلت تست، شرایط تضمین، ثبت اختلاف و فرآیند رسیدگی را به‌صورت کامل فعال کنیم."))
        root.addView(space(12))
        root.addView(text("نکته: شرایط تضمین باید قبل از فعال‌سازی نهایی، دقیق و حقوقی تعریف شود.", 13f, muted))
        root.addView(space(12))
        root.addView(button("← بازگشت") { showHome() })
        setContentView(root)
    }

    private fun showExpertJoin() {
        val root = base()
        root.addView(text("همکاری به عنوان کارشناس", 25f, gold, true))
        root.addView(space(8))
        root.addView(text("نوع همکاری را انتخاب کنید", 15f, muted))
        root.addView(space(8))
        root.addView(button("🏪 فروشگاه‌دار / دارای پروانه کسب") {
            Toast.makeText(this, "فرم احراز هویت حرفه‌ای در نسخه بعد اضافه می‌شود.", Toast.LENGTH_SHORT).show()
        })
        root.addView(space(10))
        root.addView(button("🎓 دانشجوی متخصص") {
            Toast.makeText(this, "فرم آزمون مهارت و احراز هویت دانشجو در نسخه بعد اضافه می‌شود.", Toast.LENGTH_SHORT).show()
        })
        root.addView(space(12))
        root.addView(text("برای هر دو گروه، احراز هویت و ارزیابی مهارت قبل از دریافت مأموریت الزامی خواهد بود.", 13f, muted))
        root.addView(space(12))
        root.addView(button("← بازگشت") { showHome() })
        setContentView(root)
    }

    private fun space(dp: Int): Space {
        val s = Space(this)
        s.minimumHeight = (dp * resources.displayMetrics.density).toInt()
        return s
    }
}
